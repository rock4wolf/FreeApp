
public class recommend {
    void show_recomend(){
        //mostrar las recomendaciones
    }
}