class preservativo{
    String nombre;
    String tipo;
    double confianza;
    char sexo;
    String componentes;

    //mostrar recomendaciones
    //busqueda
    //leer preservativos
    //crear preservativo
}