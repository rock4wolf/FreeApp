class Alarm {
    String preserve;//preservativos
    //crear recordatorio;
    //eliminar recordatorio;
    
}