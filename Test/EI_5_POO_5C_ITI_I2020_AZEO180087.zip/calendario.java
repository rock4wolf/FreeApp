class calendario {
    int day;
    int month;
    int year;
    boolean bis;

    //contructor;
    //mostrar calendario;
    //menu de mostrar
    void show_by(){
        //escoger como se mostrara el calendario
    }
}