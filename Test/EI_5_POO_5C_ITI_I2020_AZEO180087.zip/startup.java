class startup{
    public static void main(String cye[]){
        appMenu run = new appMenu();
        run.menu_ask();
    } 
}