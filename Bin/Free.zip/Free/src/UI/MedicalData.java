/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UI;

/**
 *
 * @author erik
 */
public class MedicalData {
    String cond[] = {"Alergia al latex","Alergia a algún medicamentos","Posparto Y Lactancia","Adolescencia","Ninguna"};
    String enf[] = {"Tromboembolismo venoso","Cardiopatias","Hipertension","Obesidad","Diabetes","Tabaquismo","Dolor de cabeza","VIH(SIDA)","ETS","SEPSIS","Nuliparidad","Sangrado vaginal sin explicacion","Cancer Cervical","Enfermedad Hepatica","Ninguna"};
    String anti[] ={"Anticonceptivos hormonales combinados","Anticonceptivos orales con progestageno solo","Anticonceptivos inyectables con progestágeno solo","Implantes","DIU liberador de levonorgestrel","DIU con cobre"};
}
